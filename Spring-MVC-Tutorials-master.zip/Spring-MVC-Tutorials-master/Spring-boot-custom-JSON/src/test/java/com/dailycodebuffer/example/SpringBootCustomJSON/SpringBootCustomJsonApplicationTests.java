package com.dailycodebuffer.example.SpringBootCustomJSON;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCustomJsonApplicationTests {

	@Test
	void contextLoads() {
		assert true;
	}

}
