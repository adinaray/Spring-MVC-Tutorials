package com.dailycodebuffer.example.SpringBootServlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootServletApplicationTests {

	@Test
	void contextLoads() {
	}

}
