package com.dailycodebuffer.example.SpringBootCustomParent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCustomParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
