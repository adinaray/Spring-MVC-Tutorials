package com.dailycodebuffer.dockerpublish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerpublishApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerpublishApplication.class, args);
	}

}
