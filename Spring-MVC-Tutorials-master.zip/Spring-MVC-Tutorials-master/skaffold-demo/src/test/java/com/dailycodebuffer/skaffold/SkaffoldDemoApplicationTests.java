package com.dailycodebuffer.skaffold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkaffoldDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
