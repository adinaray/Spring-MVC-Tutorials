package com.dailycodebuffer.examples.SpringBootTutorial.ConfigurationProperties.properties;

public class ApplicationProperties {
}
