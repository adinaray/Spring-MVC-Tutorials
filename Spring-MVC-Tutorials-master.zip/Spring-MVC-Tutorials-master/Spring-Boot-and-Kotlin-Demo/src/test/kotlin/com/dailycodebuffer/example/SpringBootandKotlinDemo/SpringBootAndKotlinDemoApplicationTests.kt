package com.dailycodebuffer.example.SpringBootandKotlinDemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringBootAndKotlinDemoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
