package com.dailycodebufffer.example.SpringBootMainClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMainClassApplication2 {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootMainClassApplication2.class, args);
    }
}
