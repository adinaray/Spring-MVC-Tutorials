package com.dailycodebuffer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqsSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqsSpringBootApplication.class, args);
	}

}
