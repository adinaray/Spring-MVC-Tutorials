package com.dailycodebuffer.sns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnsSpringbootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
