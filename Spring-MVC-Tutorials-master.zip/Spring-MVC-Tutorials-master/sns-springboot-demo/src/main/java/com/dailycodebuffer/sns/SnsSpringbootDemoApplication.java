package com.dailycodebuffer.sns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnsSpringbootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnsSpringbootDemoApplication.class, args);
	}

}
