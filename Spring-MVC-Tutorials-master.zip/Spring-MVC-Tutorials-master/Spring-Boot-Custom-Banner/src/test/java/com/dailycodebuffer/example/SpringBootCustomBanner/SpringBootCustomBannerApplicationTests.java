package com.dailycodebuffer.example.SpringBootCustomBanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCustomBannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
