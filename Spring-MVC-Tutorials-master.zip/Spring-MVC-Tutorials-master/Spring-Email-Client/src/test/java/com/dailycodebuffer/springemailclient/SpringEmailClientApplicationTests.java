package com.dailycodebuffer.springemailclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmailClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
