package com.dailycodebuffer.eurekaclientapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
