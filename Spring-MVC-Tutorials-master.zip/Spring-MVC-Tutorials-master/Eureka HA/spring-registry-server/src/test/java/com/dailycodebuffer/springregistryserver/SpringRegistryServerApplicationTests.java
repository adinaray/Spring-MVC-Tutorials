package com.dailycodebuffer.springregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
