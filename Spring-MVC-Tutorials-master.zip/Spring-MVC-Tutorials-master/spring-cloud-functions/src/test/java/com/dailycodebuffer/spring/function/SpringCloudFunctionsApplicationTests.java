package com.dailycodebuffer.spring.function;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudFunctionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
