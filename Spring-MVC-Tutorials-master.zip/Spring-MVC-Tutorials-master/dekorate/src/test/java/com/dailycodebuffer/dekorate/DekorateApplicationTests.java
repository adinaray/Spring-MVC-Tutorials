package com.dailycodebuffer.dekorate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DekorateApplicationTests {

	@Test
	void contextLoads() {
	}

}
